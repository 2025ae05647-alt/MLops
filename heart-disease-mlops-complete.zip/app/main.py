"""FastAPI prediction service with basic Prometheus instrumentation."""
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException, Request, Response
from pydantic import BaseModel, Field
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from src.preprocess import FEATURES

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger('heart_api')
REQUESTS = Counter('heart_api_requests_total', 'HTTP requests', ['method', 'path', 'status'])
LATENCY = Histogram('heart_api_request_seconds', 'HTTP request duration', ['path'])


class Patient(BaseModel):
    age: float = Field(ge=0, le=120)
    sex: float
    cp: float
    trestbps: float = Field(gt=0)
    chol: float = Field(ge=0)
    fbs: float
    restecg: float
    thalach: float = Field(gt=0)
    exang: float
    oldpeak: float
    slope: float
    ca: float
    thal: float


@asynccontextmanager
async def lifespan(app: FastAPI):
    path = Path(os.getenv('MODEL_PATH', 'models/heart_disease_pipeline.joblib'))
    if not path.is_file():
        raise RuntimeError(f'Model missing: {path}. Run python -m src.train first.')
    app.state.model = joblib.load(path)
    logger.info('model_loaded path=%s', path)
    yield


app = FastAPI(title='Heart Disease Educational Prediction API', lifespan=lifespan)


@app.middleware('http')
async def monitor(request: Request, call_next):
    start = time.perf_counter()
    status = 500
    try:
        response = await call_next(request)
        status = response.status_code
        return response
    finally:
        path = request.url.path if request.url.path in ('/predict', '/health', '/metrics') else '/other'
        elapsed = time.perf_counter() - start
        REQUESTS.labels(request.method, path, str(status)).inc()
        LATENCY.labels(path).observe(elapsed)
        logger.info('method=%s path=%s status=%s duration_ms=%.2f',
                    request.method, path, status, elapsed * 1000)


@app.get('/health')
def health():
    return {'status': 'ok', 'model_loaded': hasattr(app.state, 'model')}


@app.post('/predict')
def predict(patient: Patient):
    if not hasattr(app.state, 'model'):
        raise HTTPException(status_code=503, detail='Model not loaded')
    values = patient.model_dump()
    x = pd.DataFrame([{key: values[key] for key in FEATURES}])
    probability = float(app.state.model.predict_proba(x)[0, 1])
    predicted = int(probability >= 0.5)
    return {'prediction': predicted,
            'confidence': round(max(probability, 1 - probability), 6),
            'positive_class_probability': round(probability, 6),
            'note': 'Educational prediction only; not a medical diagnosis.'}


@app.get('/metrics')
def metrics():
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)
