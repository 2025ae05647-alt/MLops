import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from src.preprocess import FEATURES, make_preprocessor
from src.train import candidate_models


def test_both_models_exist():
    assert {'logistic_regression', 'random_forest'} <= set(candidate_models())


def test_pipeline_predicts_probabilities():
    rng = np.random.default_rng(42)
    rows = []
    for i in range(30):
        row = {k: float(rng.integers(1, 5)) for k in FEATURES}
        row['age'] = 30 + i
        rows.append(row)
    model = Pipeline([('preprocess', make_preprocessor()),
                      ('model', LogisticRegression(max_iter=1000))])
    model.fit(pd.DataFrame(rows), [i % 2 for i in range(30)])
    proba = model.predict_proba(pd.DataFrame(rows[:2]))
    assert proba.shape == (2, 2)
    assert np.allclose(proba.sum(axis=1), 1)
