import pandas as pd
import pytest
from src.preprocess import FEATURES, TARGET, clean_data, make_preprocessor


def test_clean_binary_target_and_missing_values():
    row = {feature: 1 for feature in FEATURES}
    frame = pd.DataFrame([{**row, TARGET: 0}, {**row, 'ca': '?', TARGET: 2}])
    result = clean_data(frame)
    assert result[TARGET].tolist() == [0, 1]
    assert pd.isna(result.iloc[1]['ca'])


def test_missing_column_fails():
    with pytest.raises(ValueError, match='Missing columns'):
        clean_data(pd.DataFrame({'age': [40], 'target': [1]}))


def test_transformer_fits():
    rows = [{**{k: float(i + 1) for k in FEATURES}, TARGET: i % 2} for i in range(6)]
    frame = clean_data(pd.DataFrame(rows))
    transformed = make_preprocessor().fit_transform(frame[FEATURES])
    assert transformed.shape[0] == len(frame)
