from fastapi.testclient import TestClient
from app.main import app

SAMPLE = {'age': 63, 'sex': 1, 'cp': 1, 'trestbps': 145, 'chol': 233,
          'fbs': 1, 'restecg': 2, 'thalach': 150, 'exang': 0,
          'oldpeak': 2.3, 'slope': 3, 'ca': 0, 'thal': 6}


def test_endpoints():
    with TestClient(app) as client:
        assert client.get('/health').status_code == 200
        response = client.post('/predict', json=SAMPLE)
        assert response.status_code == 200
        data = response.json()
        assert data['prediction'] in (0, 1)
        assert 0 <= data['confidence'] <= 1
        assert 0 <= data['positive_class_probability'] <= 1
        assert 'heart_api_requests_total' in client.get('/metrics').text


def test_invalid_input():
    with TestClient(app) as client:
        assert client.post('/predict', json={'age': -1}).status_code == 422
