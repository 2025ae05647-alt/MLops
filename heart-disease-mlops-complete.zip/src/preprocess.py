"""Data schema, validation, and leakage-safe preprocessing."""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUMERIC = ['age', 'trestbps', 'chol', 'thalach', 'oldpeak']
CATEGORICAL = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal']
FEATURES = NUMERIC + CATEGORICAL
TARGET = 'target'


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean UCI data; binary label is any original target > 0."""
    missing = set(FEATURES + [TARGET]) - set(df.columns)
    if missing:
        raise ValueError(f'Missing columns: {sorted(missing)}')
    result = df[FEATURES + [TARGET]].copy().replace('?', np.nan)
    for col in FEATURES + [TARGET]:
        result[col] = pd.to_numeric(result[col], errors='coerce')
    result = result.dropna(subset=[TARGET]).drop_duplicates()
    if result.empty:
        raise ValueError('No labeled rows remain')
    if (result[TARGET] < 0).any():
        raise ValueError('Target values cannot be negative')
    result[TARGET] = (result[TARGET] > 0).astype(int)
    return result


def make_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([('imputer', SimpleImputer(strategy='median')),
                        ('scaler', StandardScaler())])
    categorical = Pipeline([('imputer', SimpleImputer(strategy='most_frequent')),
                            ('encoder', OneHotEncoder(handle_unknown='ignore'))])
    return ColumnTransformer([('numeric', numeric, NUMERIC),
                              ('categorical', categorical, CATEGORICAL)])
