"""Retrieve the processed Cleveland heart-disease data from UCI."""
from pathlib import Path
import pandas as pd
from src.preprocess import clean_data

URL = 'https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data'
ORIGINAL_COLUMNS = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg',
                    'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'target']


def main():
    raw_path = Path('data/raw/heart_disease_raw.csv')
    clean_path = Path('data/processed/heart_disease_clean.csv')
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    clean_path.parent.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(URL, header=None, names=ORIGINAL_COLUMNS)
    df.to_csv(raw_path, index=False)
    clean_data(df).to_csv(clean_path, index=False)
    print(f'Downloaded {len(df)} rows; saved cleaned data to {clean_path}')


if __name__ == '__main__':
    main()
