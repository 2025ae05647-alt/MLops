"""Simple command-line prediction example."""
import json
import joblib
import pandas as pd
from src.preprocess import FEATURES


def predict(payload, model_path='models/heart_disease_pipeline.joblib'):
    model = joblib.load(model_path)
    row = pd.DataFrame([{key: payload[key] for key in FEATURES}])
    probability = float(model.predict_proba(row)[0, 1])
    return {'prediction': int(probability >= 0.5),
            'confidence': float(max(probability, 1 - probability)),
            'positive_class_probability': probability}


if __name__ == '__main__':
    example = {'age': 63, 'trestbps': 145, 'chol': 233, 'thalach': 150,
               'oldpeak': 2.3, 'sex': 1, 'cp': 1, 'fbs': 1,
               'restecg': 2, 'exang': 0, 'slope': 3, 'ca': 0, 'thal': 6}
    print(json.dumps(predict(example), indent=2))
