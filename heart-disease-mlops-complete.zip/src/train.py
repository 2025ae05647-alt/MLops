"""Train, tune, evaluate, and optionally track experiments in MLflow."""
import argparse
import json
from pathlib import Path

import joblib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (ConfusionMatrixDisplay, RocCurveDisplay,
                             accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from src.preprocess import FEATURES, TARGET, clean_data, make_preprocessor


def candidate_models():
    return {
        'logistic_regression': (LogisticRegression(max_iter=2000, random_state=42),
                                {'model__C': [0.1, 1, 10]}),
        'random_forest': (RandomForestClassifier(random_state=42, n_jobs=1),
                          {'model__n_estimators': [100, 200], 'model__max_depth': [None, 8]})
    }


def train(data_path='data/processed/heart_disease_clean.csv',
          tracking=False, tracking_uri='sqlite:///mlflow.db'):
    df = clean_data(pd.read_csv(data_path))
    x_train, x_test, y_train, y_test = train_test_split(
        df[FEATURES], df[TARGET], test_size=0.2, random_state=42,
        stratify=df[TARGET])
    if y_train.nunique() != 2 or y_test.nunique() != 2:
        raise ValueError('Both classes must appear in training and test sets')
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    Path('models').mkdir(exist_ok=True)
    Path('reports/figures').mkdir(parents=True, exist_ok=True)
    mlflow = None
    if tracking:
        import mlflow as mlflow_module
        mlflow = mlflow_module
        mlflow.set_tracking_uri(tracking_uri)
        mlflow.set_experiment('heart-disease-classification')
    results = []
    best_pipeline = None
    best_score = float('-inf')
    best_name = None
    for name, (estimator, grid) in candidate_models().items():
        pipeline = Pipeline([('preprocess', make_preprocessor()), ('model', estimator)])
        search = GridSearchCV(pipeline, grid, scoring='roc_auc', cv=cv, n_jobs=1,
                              refit=True, error_score='raise')
        search.fit(x_train, y_train)
        model = search.best_estimator_
        predictions = model.predict(x_test)
        probabilities = model.predict_proba(x_test)[:, 1]
        metrics = {
            'accuracy': accuracy_score(y_test, predictions),
            'precision': precision_score(y_test, predictions, zero_division=0),
            'recall': recall_score(y_test, predictions, zero_division=0),
            'f1': f1_score(y_test, predictions, zero_division=0),
            'roc_auc': roc_auc_score(y_test, probabilities),
            'cv_roc_auc': search.best_score_,
        }
        fig, ax = plt.subplots(figsize=(6, 5))
        RocCurveDisplay.from_predictions(y_test, probabilities, ax=ax)
        fig.tight_layout()
        roc_path = f'reports/figures/{name}_new_roc.png'
        fig.savefig(roc_path, dpi=160)
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(6, 5))
        ConfusionMatrixDisplay.from_predictions(y_test, predictions, ax=ax)
        fig.tight_layout()
        cm_path = f'reports/figures/{name}_new_confusion.png'
        fig.savefig(cm_path, dpi=160)
        plt.close(fig)
        results.append({'model': name, **metrics, 'best_params': json.dumps(search.best_params_)})
        if mlflow is not None:
            with mlflow.start_run(run_name=name):
                mlflow.log_params(search.best_params_)
                mlflow.log_param('test_size', 0.2)
                mlflow.log_param('random_state', 42)
                mlflow.log_metrics(metrics)
                mlflow.log_artifact(roc_path)
                mlflow.log_artifact(cm_path)
                mlflow.sklearn.log_model(model, name='model')
        if search.best_score_ > best_score:
            best_score = search.best_score_
            best_pipeline = model
            best_name = name
    joblib.dump(best_pipeline, 'models/heart_disease_pipeline.joblib')
    pd.DataFrame(results).to_csv('reports/reproduced_model_results.csv', index=False)
    Path('reports/training_summary.json').write_text(json.dumps({
        'selected_model': best_name, 'selection_metric': '5-fold CV ROC-AUC',
        'cv_score': best_score, 'train_rows': len(x_train), 'test_rows': len(x_test),
        'source_data': data_path, 'random_state': 42,
    }, indent=2), encoding='utf-8')
    print(f'Selected: {best_name}; CV ROC-AUC: {best_score:.4f}')
    return best_pipeline


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', default='data/processed/heart_disease_clean.csv')
    parser.add_argument('--mlflow', action='store_true')
    parser.add_argument('--tracking-uri', default='sqlite:///mlflow.db')
    args = parser.parse_args()
    train(args.data, args.mlflow, args.tracking_uri)
